# Bangkok on a Budget
A fictional educational website for MKTG:4400 at the University of Iowa.

Five HTML pages and one shared CSS file.
